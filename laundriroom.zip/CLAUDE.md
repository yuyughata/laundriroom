# CLAUDE.md — orientation for Claude Code

This file gives Claude Code (and any contributor) the context to continue this
project. Read `README.md` and `docs/ARCHITECTURE.md` for the full picture.

## What this is

**laundriroom** — a two-sided laundry platform. Three surfaces on one backend:
customer PWA, vendor dashboard (tablet-first), admin dashboard (desktop-first).

**Stack:** Next.js 14 (App Router) · TypeScript · Tailwind · Supabase
(Postgres, Auth, Storage, Realtime). Theme: "Ink & Ivory" (`tailwind.config.ts`).

## How to run

```bash
npm install
cp .env.example .env.local          # fill in Supabase URL + anon key
npm run dev                         # http://localhost:3000
npm run typecheck                   # must stay clean
npm run build                       # must stay green
```

To connect a live database, follow `docs/CONNECT-DATABASE.md` end to end
(create Supabase project → apply `supabase/migrations` in order → seed →
promote an admin → deploy edge functions → wire Paystack).

## Conventions (please keep)

- **Business rules live in the database.** ID generation, price snapshots,
  stage→status transitions, payout scheduling and tag lifecycle are Postgres
  triggers/functions in `supabase/migrations/0003`. Add rules there, not only in
  the app, so every client behaves the same.
- **RLS is the security boundary.** Every table has policies
  (`0004_rls.sql`). The browser only uses the anon key. Never expose the
  service-role key to client code; use it only in server actions / edge
  functions (`src/lib/supabase/server.ts → createServiceClient`).
- **Schema changes:** add a new migration file (don't edit applied ones once the
  DB is live), then `npm run db:types` to regenerate `src/lib/database.types.ts`.
  Those entity types are `type` aliases (not `interface`) on purpose — Supabase's
  generics need the implicit index signature.
- **Money is NGN**, formatted via `src/lib/format.ts`. **Commission is the only
  revenue model** — charged on the whole order total (delivery fee included).
  Subscription/combined plans are retired (migration `0015`): any such plans are
  deactivated and their vendors moved to the default commission plan, and the
  admin Plans & fees UI only offers commission. The `plan_type` enum still holds
  the old values for history, but nothing creates them.
- **Three orthogonal order dimensions:** service *kind* per item
  (`service_type`: wash & fold / dry clean / press), quality *tier* per order
  (`service_tier`: standard / premium — premium unlocks admin-defined
  `service_extras`), and *turnaround* per order (`turnaround`: normal / express,
  with admin percentages in `platform_settings`). Order total =
  items + extras + delivery + express markup + premium markup + any reschedule
  penalty, all recomputed by DB triggers.
- **Who earns what:** standard orders stay at the vendor's price (platform earns
  via the commission, a vendor-funded discount). Express/premium markups are
  percentages kept 100% by the platform — they are excluded from the vendor
  payout (`schedule_payout_if_ready` pays on items+extras+delivery only). A
  non-collection penalty (% of delivery fee, admin-set) is added on reschedule
  when the customer was at fault (`apply_delivery_reschedule`). All three knobs
  live on Admin → Fees & charges.
- Server Components fetch; interactive bits are small client components calling
  server actions in each area's `actions.ts`.

## State of the build

**Working end to end:** auth + role routing (6 roles), the full database
(validated against Postgres, including order→pay→payout and RLS isolation),
customer order/track/pay, vendor check-in/stages/handover/requests/ledger,
admin **dashboard home (live platform totals)**, **orders overview across all
vendors**, **user management** (edit role/status, attach staff to a vendor,
delete, message by email/WhatsApp), vendors/plans/payouts/communications/
integrations, **support & complaints** (customer tickets with predefined
categories/subcategories + "Other", threaded replies; support agents handle
them under Admin → Support), **claims & lost items** (customer raises damage/loss
on an order/item; admins resolve under Admin → Claims using item-level evidence —
check-in photos + condition notes), **check-in evidence** (attendant adds photos
+ condition notes per item at check-in), **analytics** (Admin → Analytics:
revenue, avg turnaround, top items, repeat rate via `get_analytics()`),
**promo codes** (admin platform-funded at Admin → Promos, or vendor-funded at
Vendor → Promos; `redeem_promo` snapshots the discount, scopes vendor codes to
that vendor, and `schedule_payout_if_ready` deducts a vendor-funded discount
from the vendor's gross while a platform discount leaves it whole) and
**referrals** (per-customer `referral_code`; a first completed
order by a referee auto-issues an owner-scoped reward promo to the referrer),
dispatch-partner logging (`dispatch_reference`), **rider assignment**
(vendor/attendant assigns a rider — own or dispatch — on the order workspace via
`assignRider`, storing `rider_name`/`rider_phone`; the rider is shown the order
code + handover PIN to carry, and the vendor manages delivery status in-app, so
riders need no login), **QR camera scanning** (`QrScanner` + `html5-qrcode`:
attendants scan a tag's QR into the check-in form instead of typing it),
**vendor self-serve applications** (public `/apply` form inserts into
`vendor_applications` under anon RLS; admins review at Admin → Applications and
approve to auto-create a pending vendor), **platform-funded bulk discount**
(Admin → Promos: set a qualifying item count + %; `recompute_order` takes it off
the items subtotal of any order that reaches the threshold, snapshotted to
`orders.bulk_discount`; it's platform-funded so `schedule_payout_if_ready` never
deducts it from the vendor gross), **vendor KYC verification** (post-onboarding,
non-blocking: vendors upload ID + CAC to the private `vendor-docs` bucket at
Vendor → Verification; admins review and mark `vendors.kyc_verified` at
Admin → Verification), **leakage analytics** (Admin → Leakage:
`get_leakage_analytics()` surfaces per-vendor disintermediation signals —
one-and-done customer rate and lapsed-repeat customers, i.e. customers who
engaged then went quiet >45 days — to flag vendors who may be taking
platform-introduced customers off-app), **non-circumvention agreement** (shared
clause in `src/lib/legal.ts`, accepted at `/apply` with a required checkbox —
stored on `vendor_applications.agreed_terms/agreed_at` — and acknowledged in-app
by the vendor manager at Vendor → Verification, stored on
`vendors.terms_accepted_at`; admins see acceptance beside KYC), **customer reviews & ratings** (1–5 stars + comment
on a completed order; aggregated per vendor via the `vendor_ratings` view and
shown on vendor selection, the vendor Reviews page, and admin — admins moderate
under Admin → Reviews), automatic 24h payout scheduling, and tag release
on order close.

**Stubbed, ready for keys:**
- Payments — `create-payment` picks the provider from
  `platform_settings.payment_provider` (Admin → Integrations): Paystack
  (`paystack-webhook`, `PAYSTACK_SECRET_KEY`) or Flutterwave
  (`flutterwave-webhook`, `FLUTTERWAVE_SECRET_KEY` + `FLUTTERWAVE_WEBHOOK_HASH`).
  Pay-on-delivery is optional per order. Dev path simulates a paid order via the
  service key. Handover PINs: a pickup PIN (rider collects) and a handover PIN
  (delivery/collection) are generated per order (`0010`, `confirm_pickup`).
- Automated payouts (Paystack Transfers) — a vendor sets their bank account at
  Vendor → Ledger → Payout account (`vendor_payout_accounts`, name resolved via
  Paystack `/bank/resolve`). The `process-payouts` edge function runs on a cron
  (see `docs/CONNECT-DATABASE.md`): for each `due` payout it lazily creates the
  Paystack transfer recipient, checks balance, initiates the transfer
  (reference = payout id, idempotent) and sets the payout `processing`. The
  `paystack-webhook` settles `transfer.success` → `sent` and
  `transfer.failed`/`reversed` → back to `due` with a `failure_reason`. Needs
  Transfers enabled + OTP disabled on Paystack; test keys simulate the full path.
- Messaging — `supabase/functions/send-notification` has the event→rule→channel
  engine + a working Resend email adapter; WhatsApp and SMS adapters are marked
  `not implemented` where to drop your provider in. Email uses designed Ink &
  Ivory HTML templates in `src/lib/emails.ts` (one per event), mirrored to
  `supabase/functions/_shared/emails.ts` (keep both in sync). Admins preview
  all templates at `/api/emails/preview`.

## Good next tasks

- Implement the WhatsApp and SMS adapters in `send-notification`.
- Call `send-notification` from the app/DB on key events (order confirmed,
  ready, payment received).
- Invoice PDF generation + the `invoices` storage bucket.
- Item photo capture on check-in (bucket + policies already exist).
- Email the applicant on approve/reject, and the admin on a new application
  (wire `send-notification` with new events).
- Rider-facing notifications (SMS the assigned rider the code) once the SMS
  adapter lands.
- Tests: a Postgres test harness already proved the triggers; formalise it.

## Attribution for commits

```
Co-Authored-By: Claude <noreply@anthropic.com>
```
